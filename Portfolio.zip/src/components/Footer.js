import '../assets/styles.css';
function Myfooter(){
return(
    <div className="hbg container-fluid  htext text-white  text-center"> 
          <span>&copy;All rights are reserved.</span> 
    </div>
);
}
export default Myfooter;